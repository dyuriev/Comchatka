(function() {
    $(function() {
        var socket = io();

        $('.form-input').submit(function(){
            socket.emit('chat message', $('.msg-input').val());
            $('.msg-input').val('');
            return false;
        });

        socket.on('chat message', function(msg){
            $('.div-chat-messages').append($('<div class="message-line">' \
                + '<div class="user-avatar"><img src="img/avatars/coolkid.jpg" class="img-user-avatar" /></div>' \
                + '<div class="user-message clearfix">' +
                +  msg +
                + '</div>' \
            + '</div>'));
        });   
    });
}());
